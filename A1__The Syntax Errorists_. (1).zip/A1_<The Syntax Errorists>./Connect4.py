import random
import copy


def validate_input(prompt, valid_inputs):
    """
    :param prompt:The prompt to display to the user, string.
    :param valid_inputs: An appropriate list or range of values to accept
    :return:The user's input, string.

    """
    # Continuously asks the user until a valid input is entered
    while True:
        user_input = input(prompt)

        if user_input in valid_inputs:
            return user_input
        else:
            print("Invalid input, please try again.")



def create_board():
    """
    Returns a 2D list of 6 rows and 7 columns to represent
    the game board. Default cell value is 0.
    :return: A 2D list of 6x7 dimensions.
    """

    board = []
    for row in range(6):
        list_of_elements = []
        # Iterate over each column of the row
        for element in range(7):
            list_of_elements.append(0)  # 0 represents an empty slot
        # Add the row list to the board list
        board.append(list_of_elements)

    return board


def print_board(board):
    '''
    Prints the game board to the console
    :param board: The game board, 2D list of 6 rows and 7 columns
    :return: None
    '''
    # Tokens to represent the cell content
    representation = [' ', 'X', 'O']

    # Prints the Title
    dashes_left = 10
    dashes_right = 9
    print("=" * dashes_left, "Connect4", "=" * dashes_right)

    print("Player 1: X       Player 2: O\n")

    print("  1   2   3   4   5   6   7")

    for row in board:
        print((" " + '-' * 3) * 7, end='')
        print('\n', end='')

        for element in range(len(row)):
            print('| {0} '.format(representation[row[element]]), end='')

        print('|')

    print((" " + '-' * 3) * 7)
    print('=' * 29)


def drop_piece(board, player, column):
    """
        Drops a piece into the game board in the given column.
        :param board:The game board, 2D list of 6 rows and 7 columns
        :param player: The player dropping the piece, int.
        :param column: The index of column to drop the piece into, int. Indexed at 1
        :return: True if piece was successfully dropped, False if not.
    """

    column = column - 1
    # Iterate from the bottom-most row to the topmost row in a reverse order.
    # So that piece is dropped in the bottom most row.

    for row_num in [5, 4, 3, 2, 1, 0]:
        if board[row_num][column] == 0:
            board[row_num][column] = player
            return True
        # Checks if the bottommost row is empty otherwise heads to the row above it
    return False
    # returns False if True has not been returned which means all rows for that particular column is full


def execute_player_turn(player, board):
    '''
    :param player: An integer representing the player's piece
    :param board: The game board, 2D list of 6 rows and 7 columns
    :return: an int, the column the piece has successfully been dropped at
    '''
    valid_inputs = ["1", "2", "3", "4", "5", "6", "7"]

    prompt = "Player {0}, please enter the column you would like to drop your piece into: ".format(player)
    # Loop until a successful drop occurs
    while True:
        # Validate of user input
        column = int(validate_input(prompt, valid_inputs))

        drop_successful = drop_piece(board, player, column)

        # Breaks out of the while loop if the drop is successful and returns column index
        if drop_successful:
            return column
        elif drop_successful is False:
            print("That column is full, please try again.")


def end_of_game(board):
    '''
       Checks if the game has ended.
       The game ends if it is a draw a win.
       A  draw occurs if the game board is full, and an int value of 3 is returned
       A win occurs if there are 4 tokens connected horizontally, vertically, diagonally, or anti diagonally,
       When a win occurs, an int value of the player number is returned.
       else a value of 0 indicating the game has not ended yet


       :param board: The game board, 2D list of 6 rows and 7 columns
       :return: integer value that represents the current state of the game.
       '''

    # A loop which check for any horizontal wins
    for row in board:
        for element in [0, 1, 2, 3]:
            # if all( row[element] == row [element+i] for i in range(0,tokens_to_win) )
            if row[element] == row[element + 1] and row[element] == row[element + 2] and \
                    row[element] == row[element + 3]:
                if row[element] in [1, 2]:
                    return row[element]
    # A loop which check for any vertical wins
    for column_num in [0, 1, 2, 3, 4, 5, 6]:
        for row_num in [0, 1, 2]:
            if board[row_num][column_num] in [1, 2]:
                if board[row_num][column_num] == board[row_num + 1][column_num] and \
                        board[row_num][column_num] == board[row_num + 2][column_num] and \
                        board[row_num][column_num] == board[row_num + 3][column_num]:
                    return board[row_num][column_num]

    # A loop which check for any antidiagonal wins
    for row_num in [0, 1, 2]:  # 3 :
        for column_num in [0, 1, 2, 3]:  # 4 :
            element = board[row_num][column_num]
            if element != 0:
                if element == board[row_num + 1][column_num + 1] and element == board[row_num + 2] \
                        [column_num + 2] and element == board[row_num + 3][column_num + 3]:
                    return element
    # A loop which check for any diagonal wins
    for row_num in [0, 1, 2]:
        for column_num in [3, 4, 5, 6]:
            element = board[row_num][column_num]
            if element != 0:
                if element == board[row_num + 1][column_num - 1] and element == board[row_num + 2] \
                        [column_num - 2] and element == board[row_num + 3][column_num - 3]:
                    return element

    # A loop which checks if the game board is a draw
    for row in board:
        for element in row:
            if element == 0:
                return 0
    return 3



def cpu_player_easy(board, player):
    """
    A Cpu player which randomly selects a column and drops a piece.
    :param board: The game board, 2D list of 6 rows and 7 columns
    :param player: An integer representing the player's piece
    :return:column the token has successfully been dropped into.
    """
    # Loops until the piece has been successfully dropped
    drop_success = False
    while drop_success == False:
        # A random column chosen for the piece to be dropped into
        column = random.randint(1, len(board[0]))  # The range is from 1 to 7. The column is indexed at 1
        drop_success = drop_piece(board, player, column)  # Attempts to drop the piece into the column chosen
    return column  # returns column upon successful drop


def cpu_player_medium(board, player):
    """
    Executes a move for the CPU on medium difficulty.
    It first checks for an immediate win and plays that move if possible.
    If no immediate win is possible, it checks for an immediate win
    for the opponent and blocks that move. If neither of these are
    possible, it plays a random move.

    Note that the ranges in this function are indexed at 1. Drop piece expects
    column input to be indexed at 1.

    :param board: The game board, 2D list of 6 rows and 7 columns
    :param player: An integer representing the player's piece
    :return: An integer, coloumn, which is indexed at 1
    """

    for column in range(1, len(board[0]) + 1):

        copy_board = copy.deepcopy(board)
        # A deep copy of board is made and is assigned to copy_board.
        # deep copy is a method from the copy library. Any changed made to copy_board does not affect copy.deepcopy
        drop_piece(copy_board, player, column)
        #  drops a piece in board_copy
        # Checks if the drop results in a win and drops it in board if so.
        if end_of_game(copy_board) == player:
            drop_piece(board, player, column)
            print('1')
            return column

    # This for loop returns a column number if there is a move which will result in an immediate wins.
    for column in range(1, len(board[0]) + 1):

        copy_board = copy.deepcopy(board)

        for other_player in [1, 2]:

            if other_player != player:

                drop_piece(copy_board, other_player, column)

                if end_of_game(copy_board) == other_player:
                    drop_piece(board, player, column)
                    print('2')
                    return column

    drop_success = False
    while drop_success == False:
        column = random.randint(1, len(board[0]))
        drop_success = drop_piece(board, player, column)

    return column


def cpu_player_hard(board, player):
    """
    Executes a move for the CPU on hard difficulty.
    This function creates a copy of the board to simulate moves.

    It first checks for an immediate win and plays that move if possible.


    If there are no immediate winning moves for either player, the function creates a list of blocked columns. A column
    is blocked if playing a piece in that column would allow the opponent to win on their next move. This
     is particularly relevant for horizontal or diagonal winning scenarios.

    Lastly it tries to play within middle columns, in the case of connect4 that would be 4,5,6
    as that increases the chances of winning. If incase the blocked column is 4,5,6 a random move is made within the board
    elif the 4,5,6 columns are full, random moves not in the blocked column are generated.
    The only time the cpu plays into the blocked column is if it is restricted to one column.



    :param board: The game board, 2D list of 6x7 dimensions.
    :param player: The player whose turn it is, integer value of 1 or 2.
    :return: Column that the piece was dropped into, int.
    """
    # Checks if there is a move which will result in an immediate win

    # Iterate through each column in the game board
    for column in range(1, len(board[0]) + 1):

        # A deep copy of board is made and is assigned to copy_board.
        copy_board = copy.deepcopy(board)

        # Drops piece into selected column of copy_board
        drop_piece(copy_board, player, column)

        # Checks if the drop results in a win and drops it in board if so.
        if end_of_game(copy_board) == player:
            drop_piece(board, player, column)
            return column

    # Checks if there is a move which will block the opponent from scoring an immediate win
    # Iterate through each column in the game board only if a winning move is not retuned
    for column in range(1, len(board[0]) + 1):

        # Create deep copy of the original game board
        copy_board = copy.deepcopy(board)
        # Iterates through the player_ids and checks if the other players have an immediate win
        for other_players in [1,2]:

            if other_players != player:
                # Drop a piece for the other player in the current column
                drop_piece(copy_board, other_players, column)

                # If the move resulted in a win for the other player, return the column
                if end_of_game(copy_board) == other_players:
                    drop_piece(board, player, column)
                    return column

    blocked_col = []

    # Iterate through each column in the game board
    # Checks if any moves made by the cpu will allow the opponent to win if the opponent drops into the same column.
    for column_num in range(1, len(board[0]) + 1):
        # Create deep copy of the original game board
        copy_board = copy.deepcopy(board)

        # Cpu drops a token into the column
        drop_piece(copy_board, player, column_num)

        for other_players in [1,2]:
            # The other player drops a piece into the same column and checks if the move results
            # in a win for the opponent
            if other_players != player:
                drop_piece(copy_board, other_players, column_num)
                if end_of_game(copy_board) == other_players:
                    blocked_col.append(column_num)

    while True:

        # A random column is chosen from column 3 to 5

        column = random.randint(3, len(board[0]) - 2)

        # A column is empty if the topmost row has a zero in it.
        Number_of_empty_col = board[0].count(0)

        # If the number of full columns 3 or less
        if Number_of_empty_col >= 5:
            # Drops into the column if the column is not the list of blacklisted columns
            if column not in blocked_col:
                drop_piece(board, player, column)
                return column

            # If the blocked column in within the 3 middle rows, the cpu drops a piece into any col
            # which is not in the list of blacklisted columns
            elif blocked_col in range(3, len(board[0]) - 2):
                column = random.choice([1, len(board[0])])
                if column not in blocked_col:
                    drop_piece(board, player, column)
                    return column

        # If there is only one free column in the game board, drop into that column
        elif Number_of_empty_col == 1:
            column = random.randint(1, len(board[0]))
            drop_piece(board, player, column)
            return column

        # If board is nearly has 4 or less empty columns(the game board is nearly full), play into the edges
        elif Number_of_empty_col < 5:
            column = random.randint(1, len(board[0]))
            if column not in blocked_col:
                drop_piece(board, player, column)
                return column


def clear_screen():
    """
    Clears the terminal for Windows and Linux/macOS.

    :return: None
    """
    import os
    os.system('cls' if os.name == 'nt' else 'clear')


def game_against_cpu():
    """

    Starts a game of Connect 4 against the computer.
    The function prompts the user to select a level of difficulty for the computer player.
    Then randomly determine whether who will make the first move.
    The turns alternate until the game ends.

    Returns:
        None

    """

    # User selects the difficulty level of the CPU opponent
    cpu_level = int(validate_input("Choose Cpu Level:\n1. Cpu_easy\n2. Cpu_medium\n3. Cpu_hard\nEnter you choice: ",
                                   ['1', '2', '3']))
    clear_screen()

    human_player = random.randint(1, 2)
    board = create_board()

    # Control flow statements ensure that player one goes first.

    if human_player == 1:
        cpu = 2

        while end_of_game(board) == 0:
            # Human player's turn
            execute_player_turn(human_player, board)
            if end_of_game(board) != 0:
                clear_screen()
                break

            clear_screen()

            # CPU player's turn, with difficulty level determined by user input
            if cpu_level == 1:
                cpu_player_easy(board, cpu)

            elif cpu_level == 2:
                cpu_player_medium(board, cpu)

            elif cpu_level == 3:
                cpu_player_hard(board, cpu)

            if end_of_game(board) != 0:
                clear_screen()
                break

            clear_screen()
            print_board(board)

    elif human_player == 2:

        cpu = 1

        while end_of_game(board) == 0:

            # CPU player's turn, with difficulty level determined by user input
            if cpu_level == 1:
                cpu_player_easy(board, cpu)
            elif cpu_level == 2:
                cpu_player_medium(board, cpu)
            elif cpu_level == 3:
                cpu_player_hard(board, cpu)
            clear_screen()

            if end_of_game(board) != 0:
                clear_screen()
                break

            # Human player's turn
            print_board(board)
            execute_player_turn(human_player, board)
            clear_screen()
            if end_of_game(board) != 0:
                clear_screen()
                break



    if end_of_game(board) == 1:

        print("Player 1 has won")
        print("Final board:")
        print_board(board)

    elif end_of_game(board) == 2:
        clear_screen()
        print("Player 2 has won")
        print("Final board:")
        print_board(board)

    elif end_of_game(board) == 3:
        clear_screen()
        print("Game draw")
        print("Final board:")
        print_board(board)


def local_2_player_game():
    '''
    Runs a two player game of Connect4. Updates board and checks if the game has ended every turn
    :return:This function has no returns.

    '''
    # Creates a new game board
    board = create_board()

    # Loop until game ends
    game_status = True
    while game_status == True:
        # For loop alternates turns between player
        for player in [1, 2]:

            clear_screen()
            print_board(board)
            execute_player_turn(player, board)
            # breaks out of loop if game has ended
            if end_of_game(board) != 0:
                game_status = False
                break

    clear_screen()
    print("Final Board: ")
    print_board(board)

    if end_of_game(board) == 1:

        print("Player 1 has won")

    elif end_of_game(board) == 2:

        print("Player 2 has won")

    elif end_of_game(board) == 3:

        print("Game draw")


def print_rules():
    """
    Prints the rules of the game.

    :return: None
    """
    print("================= Rules =================")
    print("Connect 4 is a two-player game where the")
    print("objective is to get four of your pieces")
    print("in a row either horizontally, vertically")
    print("or diagonally. The game is played on a")
    print("6x7 grid. The first player to get four")
    print("pieces in a row wins the game. If the")
    print("grid is filled and no player has won,")
    print("the game is a draw.")
    print("=========================================")


def main():
    """
    Defines the main application loop.
    User chooses a type of game to play or to exit.

    :return: None
    """

    # Display the main menu
    print("=============== Main Menu ===============")
    print("Welcome to Connect 4!")
    print("1. View Rules")
    print("2. Play a local 2 player game")
    print("3. Play a game against the computer")
    print("4. Exit")
    print("=========================================")

    # Prompts user for input and validates it.
    menu_user_input = int(validate_input("Select an option: ", ['1', '2', '3', '4']))

    # Execute the user's selection

    if menu_user_input == 1:
        # Display the game rules
        clear_screen()
        print_rules()
        exit_input = None
        while exit_input != "E":
            exit_input = input("Enter E to go back ")
        clear_screen()

    elif menu_user_input == 2:

        # Start a local 2 player game
        clear_screen()
        local_2_player_game()

    elif menu_user_input == 3:
        # Start a game against the computer
        clear_screen()
        game_against_cpu()

    elif menu_user_input == 4:
        # Exit the program
        clear_screen()
        exit()


if __name__ == "__main__":
    clear_screen()
    while True:
        main()
