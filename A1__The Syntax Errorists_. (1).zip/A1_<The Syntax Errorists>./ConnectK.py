import random
import copy


def validate_input(prompt, valid_inputs):
    """
    :param prompt:The prompt to display to the user, string.
    :param valid_inputs: The range of values to accept, list
    :return:The user's input, string.

    """

    # Continuously asks the user until a valid input is entered
    while True:
        user_input = input(prompt)

        if user_input in valid_inputs:
            return user_input
        else:
            print("Invalid input, please try again.")




def create_board():
    """
    Prompts the user for number of rows and columns
    Returns a 2D list of  rows and  columns to represent
    the game board. Default cell value is 0.

    :return: A list of lists.
    """
    # Ask user for the number of rows and columns
    rows = int(validate_input("Enter the number of rows: ", [str(num) for num in range(999)]))
    columns = int(validate_input("Enter the number of columns: ", [str(num) for num in range(999)]))

    # Create the board with the specified number of rows and columns
    board = []
    for row in range(rows):
        list_of_elements = []
        for col in range(columns):
            list_of_elements.append(0)
        board.append(list_of_elements)

    return board


def print_board(board):
    '''
    Prints the board with appropriate formatting. Each column adjusts its width according to
    the tokens dropped and the column number.
    :param board:  The game board, 2D list of varying number of columns and rows.
    containing appropriate values representing the current state of the game
    :return:None
    '''
    # Initialize a list to hold the maximum width of each column in the game board
    max_cell_length = []

    # Loop through each column of the game board to find the cell with the greatest width the column
    # Cell width is dependent on the number of digits of the token dropped and the column heading

    for col in range(len(board[0])):

        # Set the default maximum digit count for the current column to 1
        max_digits = 1

        # Gets the length of the current column header (indexed by 1)
        column_heading = len(str(col + 1))

        for row in range(len(board)):
            # length of the element being printed in the board.
            length_of_element = len(str(all_players_tokens[board[row][col]]))

            # compares the length of the column heading(when board is printed),
            # the length of the current element and column header length
            max_digits = max(length_of_element, max_digits, column_heading)

            # Add 2 to the maximum digit count to account for the padding on either the side of the cell contents
            length_of_cell = max_digits + 2

        max_cell_length.append(length_of_cell)

    # Width of the board is equal to the cell size
    # len(board[0]) + 1 accounts for  the cell side borders.
    width_of_board = sum(max_cell_length) + len(board[0]) + 1

    # Dashes which are printed to the left and right of the title "Connectk"
    remaining_dashes = width_of_board - (len("Connectk") + 2)

    dashes_left = (remaining_dashes // 2)
    dashes_right = remaining_dashes - dashes_left

    print("=" * dashes_left, "Connectk", "=" * dashes_right)

    # prints all player number and their corresponding token
    for key in all_players_tokens:
        print("Player {0}: {1}".format(key, all_players_tokens[key]))

    # Print first column header.
    print(' ' + str(1).center(max_cell_length[0]), end='')

    for num in range(2, len(board[0]) + 1):
        print('  ' + str(num).center(max_cell_length[num - 1] - 1), end='')
    print('')

    # Print column headings based on the width of each column

    # Loops through each row of the game board
    for row in range(len(board)):

        # Initialize a string to store the contents of the current row
        formatted_row = ''

        # Loop through each column of the current row
        for col in range(len(board[row])):
            # Print the top border of the current cell based on column width
            print((" ") + '-' * max_cell_length[col], end='')

            # Append the contents of the current cell to the formatted_row string,
            # left-justifying the tokens printed within the width of the cell
            formatted_row += "| " + all_players_tokens[board[row][col]].ljust(max_cell_length[col] - 1)

        # Add a vertical line to the end of the formatted_row string to close off the row
        formatted_row += '|'

        # Print the completed row string, including the cell contents and borders
        print('\n' + formatted_row)

    # Print the bottom border of the game board based on the width of each column
    for col in range(len(board[row])):
        print((" ") + '-' * max_cell_length[col], end='')
    # Prints footer dashes
    print('\n', '=' * len(formatted_row))



def drop_piece(board, player, column):
    """
    Drops a piece into the game board in the given column.
    :param board:  The game board, 2D list of varying number of columns and rows.
    :param player: The player dropping the piece, int.
    :param column: The index of column to drop the piece into, int. Indexed at 1
    :return: True if piece was successfully dropped, False if not.
    """

    # Decrementing column index. column is 0-indexed in board
    column = column - 1
    # It iterates through from the bottommost row to -1(inclusive) with a step of -1 ( i.e in a reverse order)
    for row in range(len(board) - 1, -1, -1):

        # Checks if the current row in the column is empty
        if board[row][column] == 0:
            # Places player's piece if empty
            board[row][column] = player
            return True
        #  Iterates from the bottommost row to the topmost

    # returns False if True has not been returned. This means all rows for that particular column is full
    return False



def execute_player_turn(player, board):
    '''
    Prompts the user for a legal move given the current game board and
    executes it
    :param player: An int
    :param board:  The game board, 2D list of varying number of columns and rows.
    :return: Column the piece was dropped into,int
    '''

    # A list of valid inputs (column numbers) is created.
    valid_inputs = list(str(x) for x in range(1, len(board[0]) + 1))

    prompt = "Player {0}, please enter the column you would like to drop your piece into: ".format(player)

    # Loop until a successful drop occurs

    while True:
        # Validate of user input
        column = int(validate_input(prompt, valid_inputs))

        # Attempt to drop the player's piece in the selected column
        drop_successful = drop_piece(board, player, column)

        # Breaks out of the while loop if the drop is successful and returns column index
        if drop_successful:
            return column

        # If the selected column is full, inform the user and prompt them to select another column
        elif drop_successful == False:
            print("That column is full, please try again.")



def end_of_game(board):
    '''
    Checks if the game has ended.
    The game ends if it is a draw a win.
    Draw occurs if the game board is full and an int value of 3 is returned
    A win occurs if there are k tokens connected horizontally, vertically, diagonally, or anti diagonally,
    where k is the number of tokens needed to win.
    When a win occurs, a int value of the player number is returned.
    else a value of 0 is that the game has not ended yet
    :param board:  The game board, 2D list of varying number of columns and rows.
    :return: integer value that represents the current state of the game.
    '''

    # Checks if there are any horizontal wins in the game board

    # iterate through each row in the board
    for row in board:
        # iterate through each row in the board

        for column_num in range(len(row) - (tokens_to_win - 1)):

            # checks if there are 'tokens_to_win' non-zero equal consecutive elements in a row
            if row[column_num] != 0:

                if all(row[column_num] == row[column_num + i] for i in range(1, tokens_to_win)):
                    # returns player piece if there is
                    return row[column_num]

    # Checks if there are any vertical wins in the game board

    # iterate through each column in the board
    for column_num in range(len(board[0])):
        # iterate through each row in the board
        for row_num in range(len(board) - (tokens_to_win - 1)):

            # Checks if there are 'tokens_to_win' non-zero equal consecutive elements in the same column
            if board[row_num][column_num] != 0:
                if all(board[row_num][column_num] == board[row_num + i][column_num] for i in
                       range(1, tokens_to_win)):
                    # returns player piece if there is
                    return board[row_num][column_num]

    # Checks if there are any diagonal wins in the game board

    # iterate through each row in the board
    for row_num in range(len(board) - (tokens_to_win - 1), len(board)):
        # iterate through each column in the board
        for column_num in range(0, len(board[0]) - (tokens_to_win - 1)):
            # Checks if there are 'tokens_to_win' non-zero equal consecutive elements in the diagonal direction
            if board[row_num][column_num] != 0:
                if all(board[row_num][column_num] == board[row_num - i][column_num + i] for i in
                       range(1, tokens_to_win)):
                    # returns player piece if there is

                    return board[row_num][column_num]

    # Checks if there are any anti-diagonal wins in the game board and returns player's piece if there is a win.

    for row_num in range(0, len(board) - (tokens_to_win - 1)):  # 3

        # will go to row 2 in index
        for column_num in range(0, len(board[0]) - (tokens_to_win - 1)):
            board[row_num][column_num]
            # Checks if there are 'tokens_to_win' non-zero equal consecutive elements in the anti-diagonal direction
            if board[row_num][column_num] != 0:
                if all(board[row_num][column_num] == board[row_num + i][column_num + i] for i in
                       range(1, tokens_to_win)):

                    return board[row_num][column_num]

    # Checks if the board is full and if it is then it is a draw
    for row in board:
        for element in row:
            if element == 0:
                return 0
    return 3




# Done
def cpu_player_easy(board, player):
    """
    A Cpu player which randomly selects a column and drops a piece.
    :param board:  The game board, 2D list of varying number of columns and rows.
    :param player: An integer representing the player's piece
    :return:column the token has successfully been dropped into.
    """
    # Loops until the piece has been successfully dropped
    drop_success = False
    while drop_success != True:
        column = random.randint(1, len(board[0]))  # A random column chosen for the piece to be dropped into
        # The range is from 1 to the last column. The column is indexed at 1
        drop_success = drop_piece(board, player, column)  # Attempts to drop the piece into the column chosen
    return column  # returns column upon successful drop


def cpu_player_medium(board, player):
    '''
    Executes a move for the CPU on medium difficulty.
    It first checks for an immediate win and plays that move if possible.
    If no immediate win is possible, it checks for an immediate win
    for the opponent and blocks that move. If neither of these are
    possible, it plays a random move.

    :param board:  The game board, 2D list of varying number of columns and rows.
    :param player:  An integer representing the player's piece
    :return: Column indexed at 1 if there is an immediate win that can be scored

    The external library is imported to use the deepcopy() fucntion deepcopy() function creates a new object in
    memory that is a copy of the objected that is passed and includes any nested objects. It returns the new
    object and is independent of the original object.
    '''

    # Checks if there is a move which will result in an immediate win

    # Iterate through each column in the game board
    for column in range(1, len(board[0]) + 1):

        # A deep copy of board is made and is assigned to copy_board.
        copy_board = copy.deepcopy(board)

        # Drops piece into selected column of copy_board
        drop_piece(copy_board, player, column)

        # Checks if the drop results in a win and drops it in board if so.
        if end_of_game(copy_board) == player:
            drop_piece(board, player, column)

            return column

    # Checks if there is a move which will block an the opponent from scoring an immediate win
    # Iterate through each column in the game board only if a winning move is not retuned
    for column in range(1, len(board[0]) + 1):

        # Create deep copy of the original game board
        copy_board = copy.deepcopy(board)
        # Iterates through the player_ids and checks if the other players have an immediate win
        for other_players in player_ids:

            if other_players != player:
                # Drop a piece for the other player in the current column
                drop_piece(copy_board, other_players, column)

                # If the move resulted in a win for the other player, return the column
                if end_of_game(copy_board) == other_players:
                    drop_piece(board, player, column)

                    return column
    # Else a column is chosen randomly and a drop is made.
    drop_success = False
    while drop_success == False:
        column = random.randint(1, len(board[0]))
        drop_success = drop_piece(board, player, column)

        return column


def cpu_player_hard(board, player):
    """
    Executes a move for the CPU on hard difficulty.
    This function creates a copy of the board to simulate moves.

    It first checks for an immediate win and plays that move if possible.


    If there are no immediate winning moves for either player, the function creates a list of blocked columns. A column
    is blocked if playing a piece in that column would allow the opponent to win on their next move. This
     is particularly relevant for horizontal or diagonal winning scenarios.

    Lastly it tries to play within middle columns, in the case of connect4 that would be 4,5,6
    as that increases the chances of winning. If incase the blocked column is 3,4,5 a random move is made within the board
    elif the 4,5,6 columns are full, random moves not in the blocked column are generated.
    The only time the cpu plays into the blocked column is if it is restricted to one column.



    :param board: The game board, 2D list of 6x7 dimensions.
    :param player: The player whose turn it is, integer value of 1 or 2.
    :return: Column that the piece was dropped into, int.
    """
    # Checks if there is a move which will result in an immediate win

    # Iterate through each column in the game board
    for column in range(1, len(board[0]) + 1):

        # A deep copy of board is made and is assigned to copy_board.
        copy_board = copy.deepcopy(board)

        # Drops piece into selected column of copy_board
        drop_piece(copy_board, player, column)

        # Checks if the drop results in a win and drops it in board if so.
        if end_of_game(copy_board) == player:
            drop_piece(board, player, column)
            return column

    # Checks if there is a move which will block the opponent from scoring an immediate win
    # Iterate through each column in the game board only if a winning move is not retuned
    for column in range(1, len(board[0]) + 1):

        # Create deep copy of the original game board
        copy_board = copy.deepcopy(board)
        # Iterates through the player_ids and checks if the other players have an immediate win
        for other_players in player_ids:

            if other_players != player:
                # Drop a piece for the other player in the current column
                drop_piece(copy_board, other_players, column)

                # If the move resulted in a win for the other player, return the column
                if end_of_game(copy_board) == other_players:
                    drop_piece(board, player, column)
                    return column

    blocked_col = []

    # Iterate through each column in the game board
    # Checks if any moves made by the cpu will allow the opponent to win if the opponent drops into the same column.
    for column_num in range(1, len(board[0]) + 1):
        # Create deep copy of the original game board
        copy_board = copy.deepcopy(board)

        # Cpu drops a token into the column
        drop_piece(copy_board, player, column_num)

        for other_players in player_ids:
            # The other player drops a piece into the same column and checks if the move results
            # in a win for the opponent
            if other_players != player:
                drop_piece(copy_board, other_players, column_num)
                if end_of_game(copy_board) == other_players:
                    blocked_col.append(column_num)

    while True:

        # A random column is chosen from column 3 to 5

        column = random.randint( tokens_to_win-1, len(board[0]) - 2)

        # A column is empty if the topmost row has a zero in it.
        Number_of_empty_col = board[0].count(0)

        # If the number of full columns 3 or less
        if Number_of_empty_col >= 5:
            # Drops into the column if the column is not the list of blacklisted columns
            if column not in blocked_col:
                drop_piece(board, player, column)
                return column

            # If the blocked column in within the 3 middle rows, the cpu drops a piece into any col
            # which is not in the list of blacklisted columns
            elif blocked_col in range( tokens_to_win-1, len(board[0]) - 2):
                column = random.choice([1, len(board[0])])
                if column not in blocked_col:
                    drop_piece(board, player, column)
                    return column

        # If there is only one free column in the game board, drop into that column
        elif Number_of_empty_col == 1:
            column = random.randint(1, len(board[0]))
            drop_piece(board, player, column)
            return column

        # If board is nearly has 4 or less empty columns(the game board is nearly full), play into the edges
        elif Number_of_empty_col < (len(board[0]- tokens_to_win)-2):
            column = random.randint(1, len(board[0]))
            if column not in blocked_col:
                drop_piece(board, player, column)
                return column


def clear_screen():
    """
    Clears the terminal for Windows and Linux/MacOS.

    :return: None
    """
    import os
    os.system('cls' if os.name == 'nt' else 'clear')


def main_game(board):
    global player_ids
    global all_players_tokens
    global tokens_to_win
    limit = [str(x) for x in list(range(0, 999))]

    # Prompts user for number of human players and cpu players and their levels.

    while True:
        number_of_human_players = int(validate_input("Enter number of human players: ", limit))
        number_of_cpu_player_easy = int(validate_input("Enter number of easy CPU players: ", limit))
        number_of_cpu_players_medium = int(validate_input("Enter number of medium CPU players: ", limit))
        number_of_cpu_players_hard = int(validate_input("Enter number of hard Cpu players: ", limit))
        total_players = sum([number_of_human_players, number_of_cpu_player_easy, number_of_cpu_players_medium,
                             number_of_cpu_players_hard])

        if total_players < 2:
            print("The total number of player must be greater than 1. Try again please")
        else:
            break

    while True:
        tokens_to_win = int(validate_input("Enter the number of tokens needed to win: ", limit))
        if tokens_to_win < 2:
            print("The total number of tokens must be greater than 1. Try again please")

        else:
            break

    # Conseuctive IDs for all the game players
    humans_id = list(range(1, number_of_human_players + 1))

    cpu_easy_id = list(range(number_of_human_players + 1, number_of_human_players + number_of_cpu_player_easy + 1))

    cpu_medium_id = list(range(number_of_human_players + number_of_cpu_player_easy + 1,
                               number_of_human_players + number_of_cpu_player_easy + number_of_cpu_players_medium + 1))

    cpu_hard_id = list(range(number_of_human_players + number_of_cpu_player_easy + number_of_cpu_players_medium + 1,
                             total_players + 1))

    player_ids = list(range(1, total_players + 1))

    # Assigns each player  a unique token and ID via dictionary. Allows players to be
    # represented in the game board with the token of their choice.

    all_players_tokens = {0: ' '}

    for player in player_ids:
        while True:

            while True:
                player_token = input("Enter player's " + str(player) + " token: ")
                if player_token.isalnum() == False:
                    print("Enter valid token with no whitespaces")
                else:
                    break

            if player_token not in all_players_tokens.values():

                all_players_tokens[player] = player_token
                break
            else:
                print(player_token + " is already taken")

    # Game execution
    # Shuffles player turns once.

    random.shuffle(player_ids)
    while end_of_game(board) == 0:

        for player in player_ids:

            # Breaks if the game has ended
            if end_of_game(board) != 0:
                clear_screen()
                break

            # executes player turn and prints their move
            if player in cpu_easy_id:
                column = cpu_player_easy(board, player)
                print("Player {0} (CPU Easy) played into column".format(player), column)
            elif player in cpu_medium_id:

                column = cpu_player_medium(board, player)
                print("Player {0} (CPU Medium) played into column".format(player), column)

            elif player in cpu_hard_id:
                column = cpu_player_hard(board, player)
                print("Player {0} (CPU Hard) played into column".format(player), column)

            elif player in humans_id:
                clear_screen()
                print_board(board)
                column = execute_player_turn(player, board)
                print("Player {0} (Human) played into column".format(player), column)


# Done
def print_rules():
    """
    Prints the rules of the game.

    :return: None
    """
    print("================= Rules =================")
    print("Connect K is a two-player game where the")
    print("objective is to get K of your pieces in a ")
    print("row either horizontally, vertically or diagonally.")
    print("The game is played on a square grid, which can ")
    print("vary in size depending on the player's preference")
    print("The first player to get k pieces in a row  ")
    print(" wins the game. If the grid is filled and")
    print("no player has won, the game is a draw.")
    print("=========================================")




def main():
    '''
        User chooses a type of game to play or to exit.
        :return:None
    '''
    print("=============== Main Menu ===============")
    print("Welcome to Connect 4!")
    print("1. View Rules")
    print("2. Play Connect K")
    print("3. Exit")
    print("=========================================")

    # Prompts user for input and validates it.
    menu_user_input = validate_input("Select an option: ", ['1', '2', '3', '4'])

    # Execute the user's selection
    if menu_user_input == '1':
        # Display the game rules
        clear_screen()
        print_rules()
        exit_input = None
        while exit_input != "E":
            exit_input = input("Enter E to go back ")
        clear_screen()

    elif menu_user_input == '2':
        # Starts Connectk
        clear_screen()
        game_board = create_board()
        main_game(game_board)

        if end_of_game(game_board) == 3:
            print("Game Draw")
            print("Final Game board:")
            print_board(game_board)

        else:
            print("Player {} has won".format(end_of_game(game_board)))
            print("Final Game board:")
            print_board(game_board)

    elif menu_user_input == '3':
        # Exit the program
        clear_screen()
        exit()



if __name__ == "__main__":
    # Enter test code below

    while True:
        main()
